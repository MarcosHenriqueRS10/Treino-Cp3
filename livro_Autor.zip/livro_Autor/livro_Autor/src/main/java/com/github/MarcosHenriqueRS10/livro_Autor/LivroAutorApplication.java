package com.github.MarcosHenriqueRS10.livro_Autor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivroAutorApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivroAutorApplication.class, args);
	}

}
