package com.github.MarcosHenriqueRS10.livro_Autor.dto;

import com.github.MarcosHenriqueRS10.livro_Autor.Entity.Autor;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter

public class AutorDTO {

    private Long id;

    @NotBlank(message = "o nome não pode ser vazio")
    @Size(min = 3, max = 100, message = "o tamsnho so pode ser de 3 ate 100 caracteres")
    private String nome;

    @NotBlank(message = "o emial do usuário não pode ser vazio")
    @Size(min = 3,max = 50,message = "o email deve ter de 3 ate 50 caracteres")
    private String email;

    public AutorDTO(Autor entity) {
        id = entity.getId();
        nome = entity.getNome();
        email = entity.getEmail();
    }
}
