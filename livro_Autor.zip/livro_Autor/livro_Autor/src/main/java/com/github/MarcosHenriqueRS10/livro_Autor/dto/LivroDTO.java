package com.github.MarcosHenriqueRS10.livro_Autor.dto;


import com.github.MarcosHenriqueRS10.livro_Autor.Entity.Autor;
import com.github.MarcosHenriqueRS10.livro_Autor.Entity.Livro;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class LivroDTO {
    private Long id;

    @NotEmpty(message = "titulo do livro requerido")
    @Size(min = 3,max = 150,message = "O tirulo do livro é obrigatorio")
    private String titulo;

    @NotEmpty(message = "ano de publicação requerido")
    @NotNull
    private Integer anoDePublicacao;

    private Set<AutorDTO> autores = new HashSet<>();

    public LivroDTO(Livro entity) {
        id = entity.getId();
        titulo = entity.getTitulo();
        anoDePublicacao = entity.getAnoDePublicacao();

        for (Autor autor : entity.getAutores()){
            AutorDTO autorDTO = new AutorDTO(autor);
            autores.add(autorDTO);

        }
    }
}
