package com.github.MarcosHenriqueRS10.livro_Autor.Repository;

import com.github.MarcosHenriqueRS10.livro_Autor.Entity.Autor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AutorRepository extends JpaRepository <Autor, Long>{
}
