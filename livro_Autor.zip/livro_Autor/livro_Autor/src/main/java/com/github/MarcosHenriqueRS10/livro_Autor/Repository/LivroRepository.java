package com.github.MarcosHenriqueRS10.livro_Autor.Repository;

import com.github.MarcosHenriqueRS10.livro_Autor.Entity.Livro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LivroRepository extends JpaRepository <Livro,Long>{

}
