package com.github.MarcosHenriqueRS10.livro_Autor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivroAutorApplicationTests {

	@Test
	void contextLoads() {
	}

}
